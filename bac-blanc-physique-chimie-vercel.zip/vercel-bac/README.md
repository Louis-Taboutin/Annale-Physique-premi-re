# Bac Blanc — Physique-Chimie Première

Cours complet + 55 exercices corrigés pour réviser le bac blanc.

## Déployer sur Vercel

### Option 1 — Via GitHub (recommandé)
1. Crée un repo GitHub et push ce dossier
2. Va sur [vercel.com](https://vercel.com), connecte ton compte GitHub
3. Clique **Add New Project** → sélectionne le repo → **Deploy**

### Option 2 — Via Vercel CLI
```bash
npm i -g vercel
cd bac-blanc-physique-chimie
vercel
```
Suis les instructions dans le terminal, c'est tout.

### Option 3 — Drag & drop
1. Va sur [vercel.com/new](https://vercel.com/new)
2. Glisse le dossier `public/` directement dans la zone de drop
